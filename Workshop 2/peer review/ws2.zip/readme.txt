1. Extract folder ws2 inte hard disk
2. Read readme.pdf
3. Enjoy!
