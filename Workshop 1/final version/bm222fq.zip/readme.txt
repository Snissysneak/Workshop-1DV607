Domain model authors:

Rasmus Dahlberg - rd222gb
Jonathan Appelqvist - ja223wj
Bartlomiej Minierski - bm222fq